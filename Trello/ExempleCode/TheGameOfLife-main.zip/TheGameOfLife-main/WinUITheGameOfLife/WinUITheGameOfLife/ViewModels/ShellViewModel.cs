﻿using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.UI.Xaml.Controls;
using WinUITheGameOfLife.Views;

namespace WinUITheGameOfLife.ViewModels
{
    public class ShellViewModel : ObservableRecipient
    {
        public ShellViewModel()
        {
        }
    }
}
