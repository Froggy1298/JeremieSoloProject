﻿using System;
namespace MVVM.Life.ViewModels
{
    public interface ISettingsViewModel
    {
        
    }
}
