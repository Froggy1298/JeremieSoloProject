﻿using System;
namespace MVVM.Life.ViewModels
{
    public interface IGameViewModel
    {
    }
}
