﻿namespace MVVM.Life.Common.Models
{
    public interface ICoordinate
    {
        int X { get; set; }
        int Y { get; set; }
    }
}
