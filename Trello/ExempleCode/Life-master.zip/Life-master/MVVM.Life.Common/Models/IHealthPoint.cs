﻿
namespace MVVM.Life.Common.Models
{
    public interface IHealthPoint
    {
        decimal Value { get; }
        bool Inclusive { get; }
    }
}
