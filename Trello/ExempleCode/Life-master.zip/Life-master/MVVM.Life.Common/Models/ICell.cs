﻿namespace MVVM.Life.Common.Models
{
    public interface ICell
    {
        decimal Health { get; set; }
    }
}
