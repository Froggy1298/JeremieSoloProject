﻿using LifeGameProject.Static;

namespace LifeGameProject.Models
{
    public class ValueDescription
    {
        public ValueDescription()
        {
        }

        public SettingType Value { get; set; }
        public string Description { get; set; }
    }
}