﻿using Prism.Events;

namespace LifeGameProject.Events
{
    internal class SaveGameEvent : PubSubEvent
    {
    }
}
