﻿using Prism.Events;

namespace LifeGameProject.Events
{
    internal class LoadGameEvent : PubSubEvent<string>
    {

    }
}
