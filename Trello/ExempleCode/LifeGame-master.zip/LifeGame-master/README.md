# LifeGame
C# .NET WPF Prism(MVVM) Life Game
Implementing MVVM pattern using Prism framework.
Using Bindings, Commands, Events.
