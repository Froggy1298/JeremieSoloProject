# GameofLife
Fast WPF implementation  of Game of Life with save and load options, resizable big canvas, and two kind of cells.
![demopicture](https://i.imgur.com/CQVvfL7.png)

[Demo video](https://s2.gifyu.com/images/ezgif.com-optimize-52d1edcfbad146412.gif)
